<?php
                

/**
* Plugin Name: Build With Two Admin Pages
* Plugin URI: 
* Description: 
* Version: 0.0.1
* Requires at least: 5.7
* Requires PHP:      7.1.0
* Author:            
* Author URI:        
* License:           GPL v2 or later
* License URI:       https://www.gnu.org/licenses/gpl-2.0.html
* Text Domain:       build-with-two-admin-pages
* Domain Path:       /languages
*/

include_once dirname( __FILE__ ). '/inc/functions.php';
include_once dirname( __FILE__ ). '/inc/hooks.php';
include_once dirname( __FILE__ ) . '/admin/build-with-two-admin-pages-0/init.php';

include_once dirname( __FILE__ ) . '/admin/build-with-two-admin-pages-1/init.php';
